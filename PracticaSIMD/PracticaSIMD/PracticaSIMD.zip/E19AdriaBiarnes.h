#pragma once
#include <vector>
#include <chrono>
#include <iostream>
#include <functional>

class E19AdriaBiarnes
{
public:

	struct Particle
	{
		float px, py, vx, vy;
		Particle(float _px, float _py, float _vx, float _vy) :px(_px), py(_py), vx(_vx), vy(_vy) { }
	};
	
	std::vector<Particle> particles = std::vector<Particle>();

	E19AdriaBiarnes();
	void Add(float px, float py, float vx, float vy);
	void Update(float dt);
	void Run(std::function<void(float x, float y)>f);
};

